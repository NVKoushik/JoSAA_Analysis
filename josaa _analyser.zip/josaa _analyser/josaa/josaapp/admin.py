from django.contrib import admin
from .models import SeatAllotment

admin.site.register(SeatAllotment)

# Register your models here.
